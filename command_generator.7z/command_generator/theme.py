# cmd_exe/theme.py
from nicegui import ui

# --- 纯净配色 ---
RED_BASE = "#DC0A2D"        # 图鉴红
DARK_RED = "#8B0000"        # 深红边框
SCREEN_BG = "#E0F8CF"       # 经典GB绿屏
SCREEN_TEXT = "#081820"     # 屏幕黑字
SHELL_GREY = "#D1D5DB"      # 卡带灰
JET_BLACK = "#202020"       # 墨黑

# --- CSS 样式 ---
PIXEL_CSS = '''
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Press+Start+2P&family=VT323&display=swap');
        @import url('https://cdn.jsdelivr.net/npm/zpix-pixel-font@3.1.5/zpix.min.css');

        /* 1. 全局设置 */
        body {
            background-color: #202020;
            font-family: 'VT323', 'Zpix', monospace;
            font-size: 22px;
            color: #E0F8CF;
        }
        
        /* 强制图片像素化 (清晰不模糊) */
        .pixelated {
            image-rendering: pixelated;
        }

        /* 2. 网格布局 (解决填充问题) */
        .poke-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 1.5rem;
            width: 100%;
            padding-right: 10px;
        }

        /* 3. 输入框深度修正 (解决对齐问题) */
        .nes-input .q-field__control {
            background-color: white !important;
            border: 4px solid #202020 !important;
            border-radius: 0 !important;
            height: 50px !important;
            padding: 0 10px !important;
        }
        .nes-input .q-field__native {
            color: #202020 !important;
            font-family: 'VT323', 'Zpix', monospace;
            font-size: 24px;
            padding-top: 4px;
        }
        .nes-input .q-field__control:before, .nes-input .q-field__control:after {
            display: none !important;
        }
        /* 绿屏版输入框 */
        .gb-input .q-field__control {
            background-color: #E0F8CF !important;
            border: 4px solid #081820 !important;
        }
        .gb-input .q-field__native {
            color: #081820 !important;
        }

        /* 4. 精灵球按钮 (纯圆 + 开合动画) */
        .pokeball-btn {
            width: 80px; height: 80px;
            border-radius: 50%;
            border: 4px solid #202020;
            position: relative;
            background: #202020;
            cursor: pointer;
            box-shadow: 4px 4px 0 rgba(0,0,0,0.5);
            transition: transform 0.1s;
            overflow: hidden;
        }
        .pokeball-btn:active { transform: scale(0.95); box-shadow: 2px 2px 0 rgba(0,0,0,0.5); }
        
        /* 红半球 */
        .ball-top {
            position: absolute; top: 0; left: 0; width: 100%; height: 50%;
            background: #DC0A2D; border-bottom: 3px solid #202020;
            transition: transform 0.4s cubic-bezier(0.6, -0.28, 0.735, 0.045);
            z-index: 2;
        }
        /* 白半球 */
        .ball-btm {
            position: absolute; bottom: 0; left: 0; width: 100%; height: 50%;
            background: #FFFFFF; border-top: 3px solid #202020;
            transition: transform 0.4s cubic-bezier(0.6, -0.28, 0.735, 0.045);
            z-index: 2;
        }
        /* 中间按钮 */
        .ball-center {
            position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);
            width: 24px; height: 24px; background: white; border: 4px solid #202020; border-radius: 50%;
            z-index: 3; transition: transform 0.2s;
        }
        /* 内部发光 */
        .ball-inner {
            position: absolute; top: 0; left: 0; width: 100%; height: 100%;
            background: radial-gradient(circle, #fff 10%, #00ffff 50%, #202020 90%);
            z-index: 1;
        }

        /* 动画状态 */
        .pokeball-btn.open .ball-top { transform: translateY(-40px); }
        .pokeball-btn.open .ball-btm { transform: translateY(40px); }
        .pokeball-btn.open .ball-center { transform: translate(-50%, -50%) scale(0); }

        /* 5. 像素按钮 (实体按键) */
        .pixel-btn {
            background: #fff; color: #202020;
            border: 4px solid #202020;
            font-family: 'Press Start 2P', 'Zpix'; font-size: 10px;
            box-shadow: 4px 4px 0 rgba(0,0,0,0.4);
            text-transform: uppercase;
        }
        .pixel-btn:active {
            transform: translate(2px, 2px); box-shadow: 2px 2px 0 rgba(0,0,0,0.4);
        }

        /* 滚动条美化 */
        ::-webkit-scrollbar { width: 12px; background: #202020; }
        ::-webkit-scrollbar-thumb { background: #DC0A2D; border: 2px solid white; }

        /* 6. Textarea 代码块样式修正 */
        .code-textarea .q-field__control {
            background-color: #202020 !important;
            border: 4px solid black !important;
            border-radius: 0 !important;
            min-height: 250px !important;
            padding: 20px !important;
        }
        .code-textarea .q-field__native {
            color: #FFFFFF !important;
            font-family: 'VT323', 'Zpix', monospace !important;
            font-size: 22px !important;
            caret-color: #E0F8CF !important;
        }
        .code-textarea .q-field__control:before, .code-textarea .q-field__control:after {
            display: none !important;
        }
    </style>
'''

def setup_theme():
    ui.add_head_html(PIXEL_CSS)