# cmd_exe/logic.py
import json
import os
import uuid
import shlex
from jinja2 import Template

# 数据存储目录
DATA_DIR = "data"
if not os.path.exists(DATA_DIR):
    os.makedirs(DATA_DIR)

class DataManager:
    def __init__(self):
        self.tag_file = os.path.join(DATA_DIR, "tags.json")
        self.tmpl_file = os.path.join(DATA_DIR, "templates.json")
        self._init_files()

    def _init_files(self):
        """初始化数据文件，如果不存在则创建默认数据"""
        if not os.path.exists(self.tag_file):
            # 默认的一些宝可梦属性Tag
            default_tags = {
                "t1": {"name": "FIRE", "color": "#F08030"},
                "t2": {"name": "WATER", "color": "#6890F0"},
                "t3": {"name": "GRASS", "color": "#78C850"},
                "t4": {"name": "ELECTRIC", "color": "#F8D030"}
            }
            with open(self.tag_file, 'w', encoding='utf-8') as f:
                json.dump(default_tags, f, indent=2)
            
        if not os.path.exists(self.tmpl_file):
            with open(self.tmpl_file, 'w', encoding='utf-8') as f:
                json.dump({}, f, indent=2)

    # ==========================
    # Tag 管理 (徽章/箱子)
    # ==========================
    def get_tags(self):
        try:
            with open(self.tag_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return {}

    def save_tag(self, name, color):
        """保存新标签"""
        if not name: return
        tags = self.get_tags()
        # 生成一个随机ID
        tid = str(uuid.uuid4())[:8]
        tags[tid] = {"name": name, "color": color}
        
        with open(self.tag_file, 'w', encoding='utf-8') as f:
            json.dump(tags, f, indent=2, ensure_ascii=False)

    def delete_tag(self, tid):
        """删除标签"""
        tags = self.get_tags()
        if tid in tags:
            del tags[tid]
            with open(self.tag_file, 'w', encoding='utf-8') as f:
                json.dump(tags, f, indent=2, ensure_ascii=False)

    # ==========================
    # 模板管理 (卡带数据)
    # ==========================
    def get_templates(self):
        try:
            with open(self.tmpl_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return {}

    def save_template(self, tid, data):
        """保存或更新模板"""
        all_data = self.get_templates()
        all_data[tid] = data
        with open(self.tmpl_file, 'w', encoding='utf-8') as f:
            json.dump(all_data, f, indent=2, ensure_ascii=False)

    def delete_template(self, tid):
        """删除模板"""
        all_data = self.get_templates()
        if tid in all_data:
            del all_data[tid]
            with open(self.tmpl_file, 'w', encoding='utf-8') as f:
                json.dump(all_data, f, indent=2, ensure_ascii=False)

    # ==========================
    # 渲染引擎 (战斗计算)
    # ==========================
    def render(self, tmpl_str, params):
        """
        渲染 Jinja2 模板
        :param tmpl_str: 模板字符串 (例如 "ping {{ target }}")
        :param params: 变量字典 (例如 {"target": "127.0.0.1"})
        """
        try:
            # 简单的安全处理：给参数加上引号转义，防止 Bash 注入 (视情况而定)
            # 这里默认不强制转义，保留原样灵活性，如果需要 shlex.quote 可以放开
            # safe_context = {k: shlex.quote(str(v)) for k, v in params.items()}
            
            # 目前直接传值，方便写复杂的脚本
            t = Template(tmpl_str)
            return t.render(**params)
        except Exception as e:
            return f"RENDER ERROR: {str(e)}"

# 单例实例，供 main.py 调用
db = DataManager()