import base64
import urllib.request
import os

# 目标文件路径
OUTPUT_FILE = "assets.py"

# 图片源 (PokeAPI)
IMAGES = {
    "BASE64_IMG_1": "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1.png",   # 妙蛙种子
    "BASE64_IMG_6": "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/6.png",   # 喷火龙
    "BASE64_IMG_25": "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/25.png", # 皮卡丘
    "BASE64_IMG_94": "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/94.png"  # 耿鬼
}

def generate_assets():
    print(f"正在下载图片并生成 {OUTPUT_FILE}，请稍候...")
    
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        f.write("# Auto-generated assets file\n\n")
        
        for var_name, url in IMAGES.items():
            try:
                print(f"正在下载: {var_name} from {url} ...")
                # 下载图片
                with urllib.request.urlopen(url) as response:
                    data = response.read()
                    # 转 Base64
                    b64_str = base64.b64encode(data).decode('utf-8')
                    # 写入变量
                    f.write(f'{var_name} = "data:image/png;base64,{b64_str}"\n\n')
                    print(f"✅ {var_name} 写入成功!")
            except Exception as e:
                print(f"❌ {var_name} 下载失败: {e}")
                # 如果失败，写入一个空的占位符防止报错
                f.write(f'{var_name} = "" # Download failed\n')

    print("-" * 30)
    print(f"🎉 完成！现在可以直接运行 python main.py 了！")

if __name__ == "__main__":
    generate_assets()