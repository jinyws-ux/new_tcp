# cmd_exe/main.py
from nicegui import ui
from logic import db
import theme
import uuid
import asyncio

# 1. 引入 Base64 资源 (必须确保 assets.py 存在且有数据)
from assets import BASE64_IMG_1, BASE64_IMG_6, BASE64_IMG_25, BASE64_IMG_94

theme.setup_theme()

# =======================================================
# 纯净像素组件 (保留你的定义)
# =======================================================

def pixel_button(text, icon=None, bg_color="#fff", text_color="black", on_click=None):
    return ui.button(text, icon=icon, on_click=on_click) \
        .style(f"background-color: {bg_color}; color: {text_color};") \
        .classes('pixel-btn w-full h-12')

def clean_input(label, value='', placeholder=''):
    """标准白底黑框输入框"""
    return ui.input(label=label, value=value, placeholder=placeholder) \
        .props('dense borderless hide-bottom-space') \
        .classes('nes-input w-full')

def screen_input(label, value='', placeholder=''):
    """绿屏风格输入框"""
    return ui.input(label=label, value=value, placeholder=placeholder) \
        .props('dense borderless hide-bottom-space') \
        .classes('nes-input gb-input w-full')

# =======================================================
# 页面布局
# =======================================================

search_input = None

# 1. 顶栏 (简洁红白机风)
with ui.header().classes('bg-[#DC0A2D] border-b-8 border-[#8B0000] h-24 p-0'):
    with ui.row().classes('w-full h-full items-center px-8 justify-between'):
        
        # 左侧：皮卡丘 (改用 Base64)
        with ui.row().classes('items-center gap-4'):
            # !!! 替换为 assets 变量 !!!
            ui.image(BASE64_IMG_25).classes('w-20 h-20 pixelated -mb-4')
            
            with ui.column().classes('gap-0'):
                ui.label('POKÉ-DEX').classes('text-white text-3xl font-bold tracking-widest').style("font-family: 'Press Start 2P'; text-shadow: 4px 4px 0 #202020;")
                ui.label('Version 8.0').classes('text-[#FFDE00] text-xs font-bold')

        # 右侧：装饰灯
        with ui.row().classes('gap-2'):
            ui.element('div').classes('w-4 h-4 bg-blue-400 rounded-full border-2 border-black')
            ui.element('div').classes('w-4 h-4 bg-yellow-400 rounded-full border-2 border-black')
            ui.element('div').classes('w-4 h-4 bg-green-400 rounded-full border-2 border-black')

# 2. 主体容器
with ui.row().classes('w-full h-[calc(100vh-96px)] gap-0 no-wrap items-stretch bg-[#202020]'):
    
    # === 左侧：菜单面板 ===
    with ui.column().classes('w-[300px] h-full p-6 gap-6 flex-shrink-0 bg-[#D1D5DB] border-r-8 border-[#202020]'):
        
        # 搜索区
        with ui.column().classes('w-full gap-2'):
            ui.label('SEARCH').classes('text-[#202020] text-xs font-bold').style("font-family: 'Press Start 2P';")
            search_input = ui.input(placeholder='NAME / TAG...') \
                .props('dense borderless input-class="text-[#202020]"') \
                .classes('nes-input w-full')

        ui.separator().classes('bg-[#202020] h-1')
        
        # 按钮区
        pixel_button('NEW ENTRY', 'add', bg_color="#23C4EA", text_color="white", on_click=lambda: open_editor())
        pixel_button('BOXES (TAG)', 'catching_pokemon', bg_color="#FFDE00", text_color="black", on_click=lambda: open_tag_manager())

        # 底部装饰
        ui.label('NINTENDO').classes('text-[#999] text-xs font-bold italic tracking-widest mt-auto mx-auto')

    # === 右侧：卡带网格 ===
    with ui.scroll_area().classes('flex-grow h-full bg-[#202020] p-8'):
        grid_container = ui.element('div').classes('poke-grid')

        def refresh_grid(filter_text=""):
            grid_container.clear()
            templates = db.get_templates()
            tags_map = db.get_tags()
            
            with grid_container:
                if not templates:
                    with ui.column().classes('w-full col-span-full items-center py-20 text-gray-500'):
                        ui.label('SLOT EMPTY').style("font-family: 'Press Start 2P'; font-size: 20px;")
                    return

                for tid, t in templates.items():
                    if filter_text and filter_text.lower() not in t['name'].lower(): continue

                    # 卡片：保留你的样式
                    with ui.card().classes('bg-[#F8F8F8] border-4 border-[#202020] flex flex-col justify-between h-52 p-0 rounded-none shadow-[8px_8px_0_rgba(0,0,0,0.5)] hover:-translate-y-1 transition-transform'):
                        
                        ui.element('div').classes('w-full h-4 bg-[#555] border-b-4 border-[#202020]')

                        with ui.column().classes('p-4 flex-grow gap-2'):
                            ui.label(t['name']).classes('text-sm font-bold text-[#202020] truncate w-full').style("font-family: 'Press Start 2P';")
                            ui.label(t.get('desc', '-')).classes('text-xs text-gray-600 line-clamp-2 leading-tight font-sans')
                            
                            with ui.row().classes('gap-1 mt-auto flex-wrap'):
                                for tag_id in t.get('tags', []):
                                    if tag_id in tags_map:
                                        ui.label(tags_map[tag_id]['name']).style(f"background: {tags_map[tag_id]['color']}; border: 2px solid #202020;") \
                                            .classes('text-white text-[10px] px-1 font-bold')

                        with ui.row().classes('w-full bg-[#202020] p-2 justify-between items-center mt-auto'):
                            ui.label(f"ID:{tid}").classes('text-gray-500 text-[10px]')
                            with ui.row().classes('gap-2'):
                                ui.button(icon='edit', on_click=lambda id=tid: open_editor(id)).props('flat dense color=white size=sm')
                                ui.button(icon='play_arrow', on_click=lambda id=tid: open_runner(id)) \
                                    .style("background: #DC0A2D; color: white; border: 2px solid white; border-radius: 0;") \
                                    .props('flat dense size=sm')

        refresh_grid()
        if search_input:
            search_input.on('change', lambda e: refresh_grid(e.value))

# =======================================================
# 弹窗 1: Tag Manager (耿鬼)
# =======================================================
def open_tag_manager():
    with ui.dialog().props('transition-show="scale" transition-hide="scale"') as dialog, \
         ui.card().classes('w-[600px] p-0 bg-[#202020] border-4 border-[#fff]'):
        
        # 头部：耿鬼 (改用 Base64)
        with ui.row().classes('bg-[#483C5C] p-4 w-full justify-between items-center border-b-4 border-white'):
            with ui.row().classes('items-center gap-4'):
                # !!! 替换为 assets 变量 !!!
                ui.image(BASE64_IMG_94).classes('w-12 h-12 pixelated')
                ui.label('GHOST STORAGE').classes('text-white text-xl').style("font-family: 'Press Start 2P';")
            ui.button(icon='close', on_click=dialog.close).props('flat dense color=white')
        
        content = ui.column().classes('p-6 w-full gap-4')
        def render_tags():
            content.clear()
            all_tags = db.get_tags()
            with content:
                with ui.row().classes('w-full gap-2 items-center mb-4 pb-4 border-b-2 border-[#555]'):
                    new_name = ui.input(placeholder='TYPE NAME...').props('dense borderless').classes('nes-input bg-white w-full flex-grow')
                    
                    with ui.column().classes('justify-center border-4 border-[#202020] bg-white p-1'):
                        color_picker = ui.color_input(value='#FF0000').props('dense borderless').style('width: 30px; height: 30px;')
                    
                    pixel_button('ADD', bg_color="#7C71D8", text_color="white", on_click=lambda: [db.save_tag(new_name.value, color_picker.value) if new_name.value else None, render_tags(), refresh_grid()]).classes('w-20')

                with ui.column().classes('w-full gap-2 max-h-[300px] overflow-y-auto pr-2'):
                    for tid, t in all_tags.items():
                        with ui.row().classes('w-full justify-between items-center bg-[#333] p-2 border-2 border-black'):
                            with ui.row().classes('items-center gap-3'):
                                ui.element('div').style(f"width: 16px; height: 16px; background: {t['color']}; border: 1px solid white;")
                                ui.label(t['name']).classes('font-bold text-white')
                            ui.button(icon='delete', on_click=lambda id=tid: [db.delete_tag(id), render_tags(), refresh_grid()]).props('flat dense color=red')
        render_tags()
        dialog.open()

# =======================================================
# 弹窗 2: 执行器 (喷火龙)
# =======================================================
def open_runner(tid):
    data = db.get_templates().get(tid)
    if not data: return
    
    with ui.dialog().props('transition-show="jump-down" transition-hide="jump-up" maximized') as dialog, \
         ui.card().classes('w-full h-full p-0 bg-[#202020] border-none'):
        
        # 头部：喷火龙 (改用 Base64)
        with ui.row().classes('w-full bg-[#F08030] p-4 border-b-8 border-black justify-between items-center'):
            with ui.row().classes('items-center gap-4'):
                # !!! 替换为 assets 变量 !!!
                ui.image(BASE64_IMG_6).classes('w-16 h-16 pixelated -my-2') 
                ui.label(f"VS. {data['name']}").style("font-family: 'Press Start 2P'; font-size: 20px; color: black;")
            ui.button('RUN', on_click=dialog.close).style("font-family: 'Press Start 2P'; border: 4px solid black; padding: 10px; background: white; color: black;")

        with ui.row().classes('w-full h-full no-wrap'):
            # 左侧：输入
            with ui.column().classes('w-1/2 h-full p-10 gap-8 bg-[#E0F8CF] border-r-8 border-black overflow-y-auto relative'):
                ui.label('ATTACK MENU').style("font-family: 'Press Start 2P'; font-size: 14px; color: #081820;")
                
                inputs = {}
                for p in data.get('params', []):
                    label = p.get('label', p['name'])
                    default_val = p.get('default', '')
                    if p.get('options'):
                        opts = [x.strip() for x in p['options'].split(',') if x.strip()]
                        safe_val = default_val if default_val in opts else (opts[0] if opts else None)
                        inputs[p['name']] = ui.select(options=opts, value=safe_val, label=label).props('filled options-dense square').classes('nes-input gb-input w-full')
                    else:
                        inputs[p['name']] = screen_input(label, value=default_val)
                
                ui.element('div').classes('flex-grow')
                
                async def run_gen(ball_el):
                    try:
                        ball_el.classes('open')
                        await asyncio.sleep(0.4)
                        pvals = {k: v.value for k,v in inputs.items()}
                        res = db.render(data.get('template', ''), pvals)
                        res_box.content = res
                        ui.notify('CRITICAL HIT!', color='green')
                        await asyncio.sleep(1.0)
                        ball_el.classes(remove='open')
                    except Exception as e:
                        ui.notify(f'MISSED: {str(e)}', color='red')
                        ball_el.classes(remove='open')

                with ui.row().classes('w-full justify-center pb-10'):
                    ball = ui.element('div').classes('pokeball-btn')
                    with ball:
                        ui.element('div').classes('ball-top')
                        ui.element('div').classes('ball-btm')
                        ui.element('div').classes('ball-center')
                        ui.element('div').classes('ball-inner')
                    
                    ball.on('click', lambda: run_gen(ball))

                ui.label('THROW BALL').classes('w-full text-center text-xs font-bold text-[#081820]')

            # 右侧：输出
            with ui.column().classes('w-1/2 h-full p-10 bg-[#081820]'):
                ui.label('BATTLE LOG').style("font-family: 'Press Start 2P'; color: #E0F8CF; margin-bottom: 10px;")
                res_box = ui.code('Waiting for move...').style("color: #E0F8CF; font-family: 'VT323'; font-size: 24px; background: transparent;").classes('w-full h-full p-6 overflow-auto border-4 border-[#E0F8CF]')
                ui.button('COPY', on_click=lambda: ui.clipboard.write(res_box.content)).style("background: #E0F8CF; color: #081820; border: 4px solid #E0F8CF; position: absolute; bottom: 20px; right: 20px; font-family: 'Press Start 2P';")

    dialog.open()

# =======================================================
# 弹窗 3: 编辑器 (妙蛙种子) - 关键修复
# =======================================================
def open_editor(tid=None):
    is_edit = tid is not None
    data = db.get_templates().get(tid, {}) if is_edit else {}
    current_params = data.get('params', [])
    current_tag_ids = set(data.get('tags', []))

    with ui.dialog().props('transition-show="scale" transition-hide="scale" maximized') as dialog, \
         ui.card().classes('w-full h-full p-0 bg-[#E0F8CF]'):
        
        # 头部：妙蛙种子 (使用 Base64)
        with ui.row().classes('w-full bg-[#78C850] p-4 justify-between items-center border-b-8 border-black'):
            with ui.row().classes('items-center gap-4'):
                # !!! 替换为 assets 变量 !!!
                ui.image(BASE64_IMG_1).classes('w-16 h-16 pixelated -my-2')
                ui.label('POKEDEX ENTRY').classes('text-2xl text-black').style("font-family: 'Press Start 2P';")
            ui.button(icon='close', on_click=dialog.close).props('flat dense color=black size=lg')

        with ui.column().classes('w-full h-full overflow-y-auto p-10 gap-8'):
            # 基础信息
            with ui.row().classes('w-full gap-8'):
                name_input = clean_input('NAME', value=data.get('name','')).classes('w-1/3')
                desc_input = clean_input('DESCRIPTION', value=data.get('desc','')).classes('flex-grow')
            
            # Tags 区 (修复了你的代码里缩进和逻辑混乱的地方)
            with ui.column().classes('w-full p-4 bg-white border-4 border-black gap-2'):
                ui.label('TYPE').classes('text-black font-bold').style("font-family: 'Press Start 2P'; font-size: 12px;")
                
                # --- 修复核心：函数定义提到循环外，或者使用闭包 ---
                # 这里我们直接在循环里处理，结构更清晰
                with ui.row().classes('w-full flex-wrap gap-2'):
                    
                    # 状态更新辅助函数
                    def toggle_tag(tag_id, btn):
                        if tag_id in current_tag_ids:
                            current_tag_ids.remove(tag_id)
                            btn.style(f"background: white; color: black; border: 2px solid #ccc;")
                        else:
                            current_tag_ids.add(tag_id)
                            t_color = db.get_tags().get(tag_id, {}).get('color', '#000')
                            btn.style(f"background: {t_color}; color: white; border: 2px solid black;")

                    for t_id, t_info in db.get_tags().items():
                        is_sel = t_id in current_tag_ids
                        init_style = f"background: {t_info['color'] if is_sel else 'white'}; color: {'white' if is_sel else 'black'}; border: 2px solid { 'black' if is_sel else '#ccc' };"
                        
                        ui.button(t_info['name'], on_click=lambda e, id=t_id: toggle_tag(id, e.sender)) \
                            .props('dense no-caps').style(init_style).classes('px-3 py-2 font-bold shadow-sm')

            # 参数配置表 (修复对齐和显示)
            with ui.column().classes('w-full border-4 border-black bg-white gap-0'):
                with ui.row().classes('w-full bg-[#202020] text-white p-3'):
                    ui.label('VAR').classes('w-1/5').style("font-family: 'Press Start 2P'; font-size: 10px;")
                    ui.label('LABEL').classes('w-1/5').style("font-family: 'Press Start 2P'; font-size: 10px;")
                    ui.label('DEFAULT').classes('w-1/5').style("font-family: 'Press Start 2P'; font-size: 10px;")
                    ui.label('OPTIONS').classes('w-1/4').style("font-family: 'Press Start 2P'; font-size: 10px;")
                    ui.label('ACT').classes('w-auto')
                
                params_container = ui.column().classes('w-full gap-0')
                def render_rows():
                    params_container.clear()
                    for idx, p in enumerate(current_params):
                        with params_container:
                            with ui.row().classes('w-full items-center border-b-2 border-black p-0 gap-0'):
                                style = "border:none; border-right: 2px solid black; height: 45px; background: white; color: black;"
                                ui.input(value=p['name'], on_change=lambda e, i=idx: current_params[i].update({'name': e.value})).props('dense borderless square').style(style).classes('w-1/5 pl-4 font-bold text-red-600')
                                ui.input(value=p.get('label',''), on_change=lambda e, i=idx: current_params[i].update({'label': e.value})).props('dense borderless').style(style).classes('w-1/5 pl-4')
                                ui.input(value=p.get('default',''), on_change=lambda e, i=idx: current_params[i].update({'default': e.value})).props('dense borderless').style(style).classes('w-1/5 pl-4')
                                ui.input(value=p.get('options',''), placeholder='opt1, opt2', on_change=lambda e, i=idx: current_params[i].update({'options': e.value})).props('dense borderless').style(style).classes('w-1/4 pl-4')
                                ui.button(icon='close', on_click=lambda i=idx: [current_params.pop(i), render_rows()]).props('flat dense color=red square').classes('ml-auto mr-4')
                    with params_container:
                        pixel_button('+ ADD VAR', bg_color='#eee', on_click=lambda: [current_params.append({'name':'var','label':'','default':'','options':''}), render_rows()])
                render_rows()

            # 模板代码 (!!! 恢复白底黑字 !!!)
            ui.label('CODE BLOCK').classes('text-xl text-black font-bold mt-4').style("font-family: 'Press Start 2P';")
            t_input = ui.textarea(value=data.get('template','')).props('borderless dense') \
                .style("width:100%; min-height: 250px; background: white; padding: 20px; border: 4px solid black; color: black; font-family: monospace;") \
                .classes('code-textarea w-full')

            # 底部按钮
            with ui.row().classes('w-full justify-end gap-6 mt-4 mb-20'):
                if is_edit:
                    pixel_button('RELEASE', bg_color='#eee', text_color='red', on_click=lambda: [db.delete_template(tid), refresh_grid(), dialog.close()]).classes('w-48')
                
                def save():
                    if not name_input.value: return ui.notify('NAME MISSING!', color='negative')
                    valid_params = [p for p in current_params if p['name'].strip()]
                    db.save_template(tid if is_edit else str(uuid.uuid4())[:6], {
                        "name": name_input.value, "desc": desc_input.value,
                        "template": t_input.value, "params": valid_params,
                        "tags": list(current_tag_ids)
                    })
                    refresh_grid()
                    dialog.close()
                    ui.notify('SAVED TO DEX!', color='positive')
                pixel_button('REGISTER', bg_color=theme.SCREEN_BG, on_click=save).classes('w-64')

    dialog.open()

ui.run(title="Poké-CMD V8", native=True, window_size=(1280, 800), reload=False)